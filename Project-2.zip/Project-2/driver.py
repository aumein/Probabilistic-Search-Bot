import graph as g
import matplotlib.pyplot as plt
import numpy as np

def main():
    pass
    
    # g.testBot1()
    # g.testBot2()
    # g.testBot3(a)
    # g.testBot4()
    # g.testBot5()
    # g.testBot6()
    # g.testBot7(a)
    # g.testBot8(a)
    # g.testBot9(a)
    
    #results = {}
    #steps = np.linspace(0,1,9)
    #for a in steps:
    #    print("Simulating for a = {a:.2f}".format(a=a))
    #    count = 0
    #    for t in range(0, 5):
    #        count += g.testBot8(a)
    #   
    #    results[a]= actions
    
    # print(results)

    # a_steps = np.arange(100, 400, 50)
    # for step in a_steps:
    #   sum = 0
    #   trials = 10
    #   steps = np.linspace(0,1,trials)
    #   for x in steps:
    #     actions = g.testBot4(int(step))
    #     sum += actions
    #   print("Alpha value: ", step)
    #   print("Total: ", sum, " moves")
    #   print("Avg: ", (sum / trials), " moves")

    # for k in range(1, 31):
    #   sum = 0
    #   trials = 30
    #   steps = np.linspace(0,1,trials)
    #   for x in steps:
    #     sum += g.testBot6(int(k))
    #   print("Bot 6")
    #   print("K value: ", k)
    #   print("Total: ", sum, " moves")
    #   print("Avg: ", (sum / trials), " moves")

    # a_steps = np.arange(0.1, 1.1, 0.1)
    # for step in a_steps:
    #   sum = 0
    #   trials = 15
    #   steps = np.linspace(0,1,trials)
    #   for x in steps:
    #     sum += g.testBot4(int(step))
    #   print("Alpha value: ", step)
    #   print("Total: ", sum, " moves")
    #   print("Avg: ", (sum / trials), " moves")
    
if __name__ == "__main__":
    main()